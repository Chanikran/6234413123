package lab4_4.eample.eastersunday;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class EasterDay extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_easter_day);

        Intent intent = getIntent();
        String easterDay = intent.getStringExtra(MainActivity.NEW _MESSAGE);
        int y = Integer.parseInt(easterDay);
        int a = y%19;
        int b = y/100;
        int c = y%100;
        int d = b/4;
        int e = b%4;
        int f = (b+8)/25;
        int g = (b-f+1)/3;
        int h = ((19*a)+b-d-g+15)%30;
        int j = c/4;
        int k = c%4;
        int l = (32+(2*e)+(2*j)-h-k)%7;
        int m = (a+(11*h)+(22*l))/451;
        int month = (h+l-(7*m)+114)/31;
        int day =  ((h+l-(7*m)+114)%31)+1;

        String monthString;
        switch (month) {
            case 1:  monthString = "January";       break;
            case 2:  monthString = "February";      break;
            case 3:  monthString = "March";         break;
            case 4:  monthString = "April";         break;
            case 5:  monthString = "May";           break;
            case 6:  monthString = "June";          break;
            case 7:  monthString = "July";          break;
            case 8:  monthString = "August";        break;
            case 9:  monthString = "September";     break;
            case 10: monthString = "October";       break;
            case 11: monthString = "November";      break;
            case 12: monthString = "December";      break;
            default: monthString = "Invalid month"; break;

        }
        easterDay =  monthString+" "+ day;

        TextView textView = findViewById(R.id.textView);
        textView.setText(easterDay);
    }
}
