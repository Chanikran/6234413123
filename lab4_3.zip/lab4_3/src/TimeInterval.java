public class TimeInterval {

    private int startTime,endTime,timeDiff;
    public TimeInterval(int start,int end)
    {
        startTime=start;
        endTime=end;
        
        int allTimeStart=(startTime/100)*60+(startTime%100);
        int allTimeEnd=(endTime/100)*60+(endTime%100);
        timeDiff=allTimeEnd-allTimeStart;
    }
    public int getHours()
    {
        int hours = timeDiff/60;
        return hours;
    }
    public int getMinutes()
    {
        int minutes= timeDiff%60;
        return minutes ;
    }
    
}
