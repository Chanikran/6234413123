import java.util.Scanner;
public class TimeIntervalTester 
{
    public static void main(String[] args)
    {
        Scanner startTime = new Scanner(System.in);
        System.out.print("Enter start time: ");
        int start=startTime.nextInt();
        
        Scanner endTime = new Scanner(System.in);
        System.out.print("Enter end time: ");
        int end =endTime.nextInt();
        
        TimeInterval timeDiff=new TimeInterval(start,end);
        System.out.println(timeDiff.getHours()+" hours "+timeDiff.getMinutes()+" minutes");
    }
    
}
