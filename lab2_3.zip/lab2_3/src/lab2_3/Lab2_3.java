package lab2_3;

import java.util.Calendar;
import java.util.GregorianCalendar;

public class Lab2_3 {

    public static void main(String[] args) {
        
        GregorianCalendar today = new GregorianCalendar();
        today.add(Calendar.DAY_OF_MONTH, 100);
        
        System.out.print(today.get(Calendar.DAY_OF_WEEK));System.out.print(" ");
        System.out.print(today.get(Calendar.DAY_OF_MONTH));System.out.print(" ");
        System.out.print(today.get(Calendar.MONTH));System.out.print(" ");
        System.out.println(today.get(Calendar.YEAR));
         
        GregorianCalendar birthday = new GregorianCalendar(1999,Calendar.DECEMBER,3);
        birthday.add(Calendar.DAY_OF_MONTH, 10000);
        
        System.out.print(birthday.get(Calendar.DAY_OF_WEEK));System.out.print(" ");
        System.out.print(birthday.get(Calendar.DAY_OF_MONTH));System.out.print(" ");
        System.out.print(birthday.get(Calendar.MONTH));System.out.print(" ");
        System.out.println(birthday.get(Calendar.YEAR));
    }
    
}
