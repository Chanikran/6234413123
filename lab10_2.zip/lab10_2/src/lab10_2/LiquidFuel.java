package lab10_2;

public interface LiquidFuel 
{
    public double getRange();
    public int getEmissionTier();
}
