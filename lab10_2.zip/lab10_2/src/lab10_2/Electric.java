package lab10_2;

public interface Electric
{
    public double LOW_VOLTAGE=480;
    public double HIGH_VOLTAGE=600;
    
    public double getVoltage();
}
