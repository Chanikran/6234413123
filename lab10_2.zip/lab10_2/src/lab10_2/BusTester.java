package lab10_2;

import java.util.ArrayList;
public class BusTester 
{
   public static void main(String[] args)
   {
       ArrayList<Bus> arr =new ArrayList<>();
       Hybrid bus1=new Hybrid(45,1.2E6,Electric.HIGH_VOLTAGE,150,1);
       arr.add(bus1);
       CNGBus bus2=new CNGBus(50,1E6,200,2);
       arr.add(bus2);
       
       for(Bus bus:arr)
       {
           System.out.println("ID: "+bus.getID());
           System.out.print("Emission Tier: ");
            if (bus instanceof CNGBus) 
            {
                System.out.println(((CNGBus) bus).getEmissionTier());
            }
            else if (bus instanceof Hybrid) 
            {
                System.out.println(((Hybrid) bus).getEmissionTier());
            }
           System.out.println("Accel: "+bus.getAccel());
       }
   }
}
