package lab10_1;

public class Subject implements Evaluation
{
    private String subName;//name of subj to decide mean
    private int[] score;//array all students score max 100
    
    public Subject(String subName,int[] score)
    {
        this.subName=subName;
        this.score=score;
    }
    @Override
    public double evaluate()
    {
        int allscore=0;
        for (int i:score)
        {
            allscore+=i;
        }
        return allscore/score.length;
    }
    @Override
    public char grade(double average)
    {
        if(average>=70) {return 'P';}
        else{return 'F';}
    }
    public String toSting()
    {
        return subName;
    }
}
