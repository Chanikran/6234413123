package lab10_1;

public class Secretary extends Employee implements Evaluation
{
    private int typingSpeed;
    private int[] score;//array score secretary and optimistic
    
    public Secretary(String name,int salary,int[] score,int typingSpeed)
    {
        super(name,salary);
        this.score=score;
        this.typingSpeed=typingSpeed;
    }
    @Override
    public double evaluate()
    {
        int allscore=0;
        for(int i:score)
        {
            allscore+=i;
        }
        return allscore;
    }
    @Override
    public char grade(double allscore)
    {
        if(allscore>=90)
        {
            this.setSalary(18000);
            return 'P';
        }
        return 'F';
    }
}
