package lab12_1;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;

public class Lab12_1
{
    public static void main(String[] args) throws FileNotFoundException 
    {
        String str = "";
        Scanner scanner = new Scanner(System.in);
        boolean firstLine = true;
        int cntLine = 0;
        int cntWord = 0;
        int cntChar = 0;
        while (true) 
        {
            String line = scanner.nextLine();
            if (line.equals("quit")) 
            {
                break;
            }
            else 
            {
                if (!firstLine) 
                {
                    str += "\n";
                    str += line;
                }
                else 
                {
                    str += line;
                    firstLine = false;
                }
            }
        }
        File file = new File("output.txt");
        PrintWriter output = new PrintWriter(file);
        output.print(str);
        output.close();
        Scanner read = new Scanner(file);
        while (read.hasNextLine()) 
        {
            String line = read.nextLine();
            cntLine++;
            String[] words = line.split(" ");
            cntWord += words.length;
            cntChar+= line.length();
        }
        read.close();
        System.out.println("Total characters : "+cntChar);
        System.out.println("Total words : "+cntWord);
        System.out.println("Total lines : "+cntLine);
    }
}
