import java.util.Random;
import java.util.Scanner;

public class Game 
{
    private int playerPoint;
    private int computerPoint;
    
    Scanner playerIn = new Scanner(System.in);
    Random computerIn = new Random();
    
    private static boolean isInteger(String s)
    {
        try
        {
            Integer.parseInt(s);
        }
        catch(NumberFormatException e)
        {
            return false;
        }
        catch(NullPointerException e)
        {
            return false;
        }
        return true;
    }
    
    public void play()
    {
        int score = 0;
        while (Math.abs(playerPoint - computerPoint)<2){
            String input;
            do
            {
               System.out.print("Enter 0 for ROCK, 1 for PAPER, 2 for SCISSORS: ");
               input = playerIn.nextLine();
            }
            while (!isInteger(input) || Integer.parseInt(input)<0 || Integer.parseInt(input)>2);
            int Player = Integer.parseInt(input);
            String[] choice = {"ROCK","PAPER","SCISSORS"};
            System.out.println("You enter: "+choice[Player]);
            int Computer = computerIn.nextInt(3);
            System.out.println("Computer: "+choice[Computer]);
            String[] statusText = {"It's a tie.","You lose!","You win!"};
            if(Player==Computer)
            {
                score = 0;
            }
            else if (Player==0 && Computer==1 || Player==1 && Computer==2 || Player==2 && Computer==0)
            {
                score = 1;
                computerPoint++;
            }
            else if (Player==0 && Computer==2 || Player==1 && Computer==0 || Player==2 && Computer==1)
            {
                score = 2;
                playerPoint++;
            }
            System.out.println(statusText[score]);
        }
        if(computerPoint>playerPoint)
        {
            System.out.println("---------------------------------------\nToo bad! You lose.");
        }
        else
        {
            System.out.println("---------------------------------------\nCongrats! You win.");
        }
         System.out.println("User Score: "+playerPoint);
         System.out.println("Computer Score: "+computerPoint);
    }
}
