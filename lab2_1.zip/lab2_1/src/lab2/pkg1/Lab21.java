package lab2.pkg1;
import java.awt.Rectangle;
import java.util.*;

public class Lab21 {

    public static void main(String[] args) {
        Random generator = new Random();
        int r1X = generator.nextInt(50)+1;
        int r1Y = generator.nextInt(50)+1;
        int r1Wid = generator.nextInt(50)+1;
        int r1Hei = generator.nextInt(50)+1;
        
        int r2X = generator.nextInt(50)+1;
        int r2Y = generator.nextInt(50)+1;
        int r2Wid = generator.nextInt(50)+1;
        int r2Hei = generator.nextInt(50)+1;
        
        Rectangle r1 = new Rectangle(r1X,r1Y,r1Wid,r1Hei);
        System.out.println(r1);
                
        Rectangle r2 = new Rectangle(r2X,r2Y,r2Wid,r2Hei);
        System.out.println(r2);
        
        Rectangle r3 = r1.intersection(r2);
        System.out.println("Is the intersected rectangle empty?:"+r3.isEmpty());
    }
    
}
