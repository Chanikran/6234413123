public class PurseTester
{
    public static void main(String[] args) 
    {
        Purse wallet1 = new Purse();
        Purse wallet2 = new Purse();
        
        //test addCoin
        wallet1.addCoin("Quarter");
        wallet1.addCoin("Dime");
        wallet1.addCoin("Nickle");
        wallet1.addCoin("Penny");
        
        wallet2.addCoin("Dime");
        wallet2.addCoin("Nickle");
        
        //test toString
        System.out.println("Wallet1: "+wallet1.toString());
        System.out.println("Wallet2: "+wallet2.toString()+"\n");
        
        //test reverse
        System.out.println("Reversed wallet1: "+wallet1.reverse());
        System.out.println("Reversed wallet2: "+wallet2.reverse()+"\n");
        
        //test transfer
        wallet1.transfer(wallet2);
        System.out.println("Wallet1 when transfers to wallet2: "+wallet1.toString());
        System.out.println("Wallet2 when transfered by wallet1: "+wallet2.toString());
        
        //test sameCoin
        System.out.println("Same Coin?: "+wallet1.sameCoins(wallet2)+"\n");
        //test sameContent
        System.out.println("Same Content?: "+wallet1.sameContents(wallet2)+"\n");       
    }
}
