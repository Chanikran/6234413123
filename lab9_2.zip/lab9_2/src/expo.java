
public class expo extends Taylor
{
    public expo(int k,double x)
    {
         super(k,x);
    }
    public double getApprox()
    {
        double approx =0.0;
        for(int i=0;i<=this.getlter();i++)
        {
            approx += (Math.pow(this.getValue(),i))/factorial(i);
        }
        return approx;
    }
    public void printValue()
    {
        System.out.println("Value from Math.exp() is "+Math.exp(this.getValue())+".");
        System.out.println("Approximated value is "+this.getApprox()+".");
    }
}
