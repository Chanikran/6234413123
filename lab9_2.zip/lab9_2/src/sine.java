
public class sine extends Taylor
{
    public sine(int k,double x)
    {
        super(k,x);
    }
    public double getApprox()
    {
        double approx =0.0;
        for (int i=0; i <= this.getlter();i++)
        {
            approx += ((Math.pow(-1,i))*(Math.pow(this.getValue(),2*i+1)))/factorial(2*i+1);
        }
        return approx;
    }
    public void printValue()
    {
        System.out.println("Value from Math.sine() is "+Math.sin(this.getValue())+".");
        System.out.println("Approximated value is "+this.getApprox()+".");
    }
}
