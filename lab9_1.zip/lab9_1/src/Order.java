import java.util.ArrayList;

public class Order
{
    public static int cntOrder=0;
    private int id;
    private Customer c;
    private ArrayList<Pizza> p= new ArrayList<>();
    
    public Order(Customer c)
    {
        this.c=c; 
        cntOrder++;
    }
    public void addPizza(Pizza pizz)
    {
        p.add(pizz);
    }
    /*return
      detail order
      detail custumer
      detail pizza
      detail cost and number
    */
    public String getOrderDetail()
    {
       id=cntOrder;
       String detail="";
       for (int i=0;i<p.size();i++)
       {
           detail+=p.get(i).toString()+"\n";
       }
       return "Order id : "+id+"\n"+c.toString()+"\n"+detail+"Total pieces : "+p.size()+"\nTotal cost : "+calculatePayment();
    }
    public double calculatePayment()
    {
        double price=0.0;
        for (int i=0;i<p.size();i++)
        {
            price += p.get(i).getPrice();
        }
        double discount =c.getDiscount()/100.00;
        price -= price * discount;
        return price;
    }
}
