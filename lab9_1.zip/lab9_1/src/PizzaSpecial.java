public class PizzaSpecial extends Pizza
{
    private String special;
    public PizzaSpecial(String name,double price,String extras)
    {
        super(name,price);
        this.special=extras;
    }
    public String toString()
    {
        return super.toString()+" special : "+special;
    }
}
