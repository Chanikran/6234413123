public class Customer 
{
    private String name,tel;
    public Customer(String name,String tel)
    {
        this.name=name;
        this.tel=tel;
    }
    public String toString()
    {
        return name+" tel : "+tel;
    }
    public String getName()
    {
        return name;
    }
    public String getTel()
    {
        return tel;
    }
    public double getDiscount()
    {
        double discount=0.0;
        return discount;
    }
}
