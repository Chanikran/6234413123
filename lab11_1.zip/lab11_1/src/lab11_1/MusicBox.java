package lab11_1;
import java.util.ArrayList;

public class MusicBox implements SimpleQueue
{
    ArrayList<String>  queue = new ArrayList<>();
    @Override
    public void enqueue(Object o)
    {
        String song =(String)o;
        queue.add(song);
        System.out.println(song+" is added in queue");
    }
    @Override
    public void dequeue()
    {
        String song= queue.get(0);
        System.out.println("Now playing "+song);
        queue.remove(0);
    }
}
