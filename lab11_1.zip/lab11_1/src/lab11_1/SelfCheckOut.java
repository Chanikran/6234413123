package lab11_1;
import java.util.ArrayList;

public class SelfCheckOut  implements SimpleQueue
{
    ArrayList<Product> queue = new ArrayList<>();
     double amount=0;
    @Override
    public void enqueue(Object o)
    {
        Product prod = (Product) o;
        queue.add(prod);
        System.out.println(prod.getName()+" is added in queue");
    }
    @Override
    public void dequeue()
    {
       double price= (queue.get(0)).getPrice();
       amount+=price;
       queue.remove(0);
    }
   public double getAmount()
    {
        return amount;
    }
}