public class Car 
{
    protected double gas;//amount of gas in tank
    protected double efficiency;//eff in using gas like 20 per gallon
    
    public Car(double g,double eff)
    {
        gas=g;
        efficiency=eff;
    }
    public void drive(double distance)
    {
        if (gas-(distance/efficiency)<=0)
            {
                System.out.println("You cannot drive too far,please add gas");
            }
        else
            {
                gas = gas-(distance/efficiency);
            }
    }
    public void setGas(double amount)
    {
        gas=amount;
    }
    public double getGas()
    {
        return gas;
    }
    public double getEfficiency()
    {
        return efficiency;
    }
    public void addGas(double amount)
    {
        gas=gas+amount;
    }
}
