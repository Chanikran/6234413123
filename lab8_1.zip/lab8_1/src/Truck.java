public class Truck extends Car
{
    private double M_weight;
    private double weight;
    
    public Truck(double gas,double eff,double weight,double maxWeight)
    {
        super(gas,eff);
        M_weight=maxWeight;
        if (weight>M_weight)
            {
                this.weight=M_weight;
            }
    }
    @Override
    public void drive(double distance)
    {
        double useGas;
        if(weight<1){
            useGas = distance/efficiency ;
        }
        else if(weight<=10){
            useGas = (distance/efficiency)*1.1;
        }
        else if(weight<=20){
            useGas = (distance/efficiency)*1.2;
            
        }
        else{
            useGas = (distance/efficiency)*1.3;
        }
        
        if(useGas<=gas){
            gas=gas-useGas;
        }
        else {
            System.out.println("You cannot drive too far, please add gas");
        }
    }
}
