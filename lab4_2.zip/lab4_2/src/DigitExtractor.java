public class DigitExtractor {

    private int number;
    public DigitExtractor(int anInteger)        
    {
        number=anInteger;
    }
    public int nextDigit() 
    {
        int posDigit= number%10;
        number=(int)number/10;
        return posDigit;
        
    }  
}
