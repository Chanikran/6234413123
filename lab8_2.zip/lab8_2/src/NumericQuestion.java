import static java.lang.Math.abs;

public class NumericQuestion extends Question
{
    public NumericQuestion()
    {
        super();
    }
    public NumericQuestion(String text)
    {
        super(text);
    }
    public Boolean checkAnswer(String response)//check value between response and answer not more than 0.01
    {
        double numberRes = Double.valueOf(response);
        double numberAns = Double.valueOf(super.getAnswer());
        return abs(numberRes-numberAns)<0.01;
    }
}
