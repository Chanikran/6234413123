public class SodaCan {

    private double height;
    private double diameter;
    public SodaCan(double enterHeight,double enterDiameter)
    {
        height=enterHeight;
        diameter=enterDiameter;
    }
    public double getVolume()
    {
        double volume =Math.PI*height*Math.pow(diameter/2,2);
        return volume;
    }
    public double getSurfaceArea()
    {
        double surface = (2*Math.PI*(diameter/2)*height)+(2*Math.PI*Math.pow(diameter/2,2));
        return surface;
    }
}
