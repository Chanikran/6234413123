import java.util.Scanner;
public class SodaTester {
    
    public static void main(String[] args)
    {
        Scanner canHeight = new Scanner(System.in);
        System.out.print("Enter height: ");
        double height=canHeight.nextDouble();
        
        Scanner canDiameter = new Scanner(System.in);
        System.out.print("Enter diameter: ");
        double diameter=canDiameter.nextDouble();
        
        SodaCan Soda =new SodaCan(height,diameter);
        System.out.println("volume: "+String.format("%.2f",Soda.getVolume()));
        System.out.println("Surface area: "+String.format("%.2f",Soda.getSurfaceArea()));
    }
    
}
