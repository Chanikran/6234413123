public class CityGridTester
{       
    public static void main(String[] args) 
    {
        CityGrid city = new CityGrid(10);
        double average = 0;
        int time = 0;
        int maximum = 0;
        
        for(time=0; time<=10000; time++)
        {
            city.walk();
            average = average+city.counter();
            
            if(city.counter()>maximum)
            {
                maximum = city.counter();
            }
            
            city.reset();
        }
        double avg = average/10000;
        System.out.printf("Average number of steps that a person can take and is still in the city: %.2f\n", avg);
        System.out.println("Maximum number of steps that a person can take and is still in the city: "+maximum);
    }
    
}
