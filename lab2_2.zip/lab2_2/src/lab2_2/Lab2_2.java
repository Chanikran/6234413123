package lab2_2;

import java.io.*;
public class Lab2_2 {

    public static void main(String[] args) {
        String sentence = "Hello, World!",sentence1;
        sentence = sentence.replace('e','O');
        sentence = sentence.replace('o','e');
        sentence = sentence.replace('O','o');
        System.out.println(sentence);
    }
    
}
